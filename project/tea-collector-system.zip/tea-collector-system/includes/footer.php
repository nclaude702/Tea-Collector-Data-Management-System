  </div><!-- content-area -->
</main>
</div><!-- app-wrapper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= ASSETS_URL ?>js/main.js"></script>
</body>
</html>